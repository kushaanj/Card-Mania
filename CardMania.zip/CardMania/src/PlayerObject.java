
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * PlayerObject Class
 * This class creates objects for players. Includes constructor, setter and getter methods.
 * 
 * Version 16.02.2020
 * @author 002872 - 0040
 */


public class PlayerObject {
    

    
    private String playerName;
    private int wins;
    private int winsPlusLosses;

    
    //constructor methods

    PlayerObject() {
        
        playerName = "-";
        wins = 0;
        winsPlusLosses = 0;
    }
    
    public PlayerObject(String playerName, int wins, int winsPlusLosses){
        this.playerName = playerName;
        this.wins = wins;
        this.winsPlusLosses = winsPlusLosses;
    }
    
    //getter methods
    
    String getPlayerName(){
        return this.playerName;
    }
    
    int getWins(){
        return this.wins; 
    }
    
    int getWinsPlusLosses(){
        return this.winsPlusLosses;
    }

    
    //setter methods
    
    void setPlayerName(String playerName){
        this.playerName = playerName;
    }
    
    void setWins(int wins){
        this.wins = wins;
    }
    
    void setWinsPlusLosses(int winsPlusLosses){
        this.winsPlusLosses = winsPlusLosses;
    }

    
    public static void main(String[] args) {
       
    }
    
    
    
}
