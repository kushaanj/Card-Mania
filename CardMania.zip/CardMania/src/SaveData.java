
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Save Data Code
 * This method saves data from the PlayerDatabase to a text file
 *
 * Version 16.02.2020
 * @author 002872 - 0040
 */
public class SaveData {
    
    public static void Save () {
        
        PrintWriter dataOut;

        try {
            //dataOut stores the data of PlayerData.txt for later use
            dataOut = new PrintWriter(new FileWriter("PlayerData.txt"));
        }
        catch (IOException e) {

            //This is An Error Message if the Data Cannot be Saved into the File
            System.out.println("Error, can't save the data file");
            return;
        }

        try {

            for (int i = 0; i < MainGUI.playerDatabase.length; i++) {

                //Storing the Data from PlayerDatabase into the Text File
                dataOut.println(MainGUI.playerDatabase[i].getPlayerName());
                dataOut.println(MainGUI.playerDatabase[i].getWins());
                dataOut.println(MainGUI.playerDatabase[i].getWinsPlusLosses());

            }
        } 
        catch (IndexOutOfBoundsException e) {

            //This is an Error Message if Too Much Information Was Placed into the File
            System.out.println("Too much information in the data file");
            System.out.println("Process has been aborted");
        } 
        finally {
            dataOut.close();
        }

    }

}
