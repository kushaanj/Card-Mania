
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Loading Data Code
 * This code creates a method that loads data into the Player Database
 *
 * Version 16.02.20
 * @author 002872 - 0040
 */
public class LoadData {
    
    public static void LoadData() {

	BufferedReader dataIn;

	try {
            //dataIn will read the contents of PlayerData.txt and store them for later use
            dataIn = new BufferedReader(new FileReader("PlayerData.txt"));
	}
	catch(FileNotFoundException e) {
            //This Produces the Output For When The File Can't Be Found
            System.out.println("File not found");
            return;
	}

	try {

            for (int i=0; i < MainGUI.playerDatabase.length; i++) {

                //The Code Below Reads the Data Into The Player Database

                String playerName = dataIn.readLine();
                int wins = Integer.parseInt(dataIn.readLine());
                int winsPlusLosses = Integer.parseInt(dataIn.readLine());
                                
		MainGUI.playerDatabase[i] = new PlayerObject(playerName, wins, winsPlusLosses);
            }
	}
	catch (IOException e) {

            //The Code Below Produces An Error Message if Any Errors are Encountered
            System.out.println("Error reading from data");
	}


    }



    
}
