
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JLabel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *Blackjack Game Code
 * 
 * This is the code that runs the Blackjack Game, and allows it to be run repeatedly, whilst adding points to the user's scores.
 * INSTRUCTIONS TO THE GAME:
 * -Player or Dealer would win the round if their total is 21
 * -All Jacks, Kings and Queens are worth 10
 * -Aces are worth 1 and 11; the Player or Dealer can win the round by having a total of 21 with either Ace value
 * -The player begins the game with two cards face-up, and the dealer begins with one-card face-up and one face-down
 * -The player can add as many cards as they want to their deck (Hit button), but once their total increases beyond 21, they lose.
 * -If player decides to Stand, the dealer's cards and total will be revealed, and the dealer will draw cards from the deck until their total is greater than the Player's. If the dealer's total becomes greater than 21, they lose. If their total is greater than the player's and below 21, they would win. 
 * -If the dealer's total and player's total are equal at the end of the round, they would tie.

 * Version 16.02.20
 * @author 002872 - 0040
 */
public class BlackJackGUI extends javax.swing.JFrame {

    /**
     * Creates new form BlackJackGUI
     */
    
    //Initialising the ArrayLists that will contain cards for the player and dealer
    
    ArrayList<CardObject> playerCards = new ArrayList<CardObject> ();
    ArrayList<CardObject> dealerCards = new ArrayList<CardObject> ();
    
    //Initialising the ArrayList that will be used to deal cards    
                   
     ArrayList<CardObject> cardDatabase = new ArrayList<CardObject> ();
    
    //Initalising Variables
         
    int cardCounter = 0;
    int playerCardCounter = 0;
    int dealerCardCounter = 0;
    
             
    int playerTotalValue = 0;
    int otherPlayerTotalValue = 0; //Special case, if Aces are drawn (can be worth 1 or 11)
    int dealerTotalValue = 0;
    int otherDealerTotalValue = 0; //Special case, if Aces are drawn (can be worth 1 or 11)
    
    boolean gameOver = false;
    
    //Initialising Array of JLabels that Will Hold Card Images
    
    JLabel [] playerImages = new JLabel[11];
    int playerImageCounter = 0;
    
    JLabel [] dealerImages = new JLabel[11];
    int dealerImageCounter = 0;
    
    
    public BlackJackGUI() throws IOException {
        initComponents();
        
        //Setting the Arrays of JLabels (Card Images) with their respective JLabels

         JLabel [] tempDealerImages = new JLabel[] {dealerCard1, dealerCard2, dealerCard3, dealerCard4, dealerCard5, dealerCard6, dealerCard7, dealerCard8, dealerCard9, dealerCard10, dealerCard11};
         JLabel [] tempPlayerImages = new JLabel[] {playerCard1, playerCard2, playerCard3, playerCard4, playerCard5, playerCard6, playerCard7, playerCard8, playerCard9, playerCard10, playerCard11};
         
         playerImages = tempPlayerImages;
         dealerImages = tempDealerImages;
         
         //Randomizing and Creating the Deck of 52 Cards and Making their Jacks, Queens and Kings's Values Equal to 10
         
         CardObject.createCardDeck(cardDatabase);
         cardDatabase = CardObject.shuffleCardDeck(cardDatabase);
         CardObject.makeJacksKingsQueensValueTo10(cardDatabase);
         
         //Adding two cards to the Player Deck
  
         playerCards.add(cardDatabase.get(cardCounter));
         playerCards.add(cardDatabase.get(cardCounter +1));
         
         //Setting the Jlabels to the Player Card Images Above
         
         playerImages[playerImageCounter].setIcon(new javax.swing.ImageIcon(getClass().getResource("/" + playerCards.get(0).getCardImage())));
         playerImageCounter++;
         playerImages[playerImageCounter].setIcon(new javax.swing.ImageIcon(getClass().getResource("/" + playerCards.get(1).getCardImage())));
         playerImageCounter++;
         
         //Calculating Player's Total and their Other Total (special cases, if the Player's Cards Are Aces)
         
         if(playerCards.get(0).getCardValue() == 1 && playerCards.get(1).getCardValue() != 1){
             playerTotalValue = 1 + playerCards.get(1).getCardValue();
             otherPlayerTotalValue = 11 + playerCards.get(1).getCardValue();
         }
         else if(playerCards.get(0).getCardValue() != 1 && playerCards.get(1).getCardValue() == 1){
             playerTotalValue = 1 + playerCards.get(0).getCardValue();
             otherPlayerTotalValue = 11 + playerCards.get(0).getCardValue();
         }
         else if(playerCards.get(0).getCardValue() == 1 && playerCards.get(1).getCardValue() == 1){
             playerTotalValue = 2;
             otherPlayerTotalValue = 22;
         }
         else{
             playerTotalValue = playerCards.get(0).getCardValue() + playerCards.get(1).getCardValue();
             otherPlayerTotalValue = playerCards.get(0).getCardValue() + playerCards.get(1).getCardValue();
         }
         
         //Adding two cards to the Dealer Deck
         
         dealerCards.add(cardDatabase.get(cardCounter +2));
         dealerCards.add(cardDatabase.get(cardCounter +3));
         
         //Setting the Jlabels to the Dealer Card Images Above, and Leaving the Second Card Face-Down
         
         dealerImages[dealerImageCounter].setIcon(new javax.swing.ImageIcon(getClass().getResource("/" + dealerCards.get(0).getCardImage())));
         dealerImageCounter++;
         dealerImages[dealerImageCounter].setIcon(new javax.swing.ImageIcon(getClass().getResource("/backOfCard.png")));
         dealerImageCounter++;
         
         //Calculating Dealer's Total and their Other Total (special cases, if the Dealer's Cards Are Aces)
         
         if (dealerCards.get(0).getCardValue() == 1 && dealerCards.get(1).getCardValue() != 1) {
            dealerTotalValue = 1 + dealerCards.get(1).getCardValue();
            otherDealerTotalValue = 11 + dealerCards.get(1).getCardValue();
        } else if (dealerCards.get(0).getCardValue() != 1 && dealerCards.get(1).getCardValue() == 1) {
            dealerTotalValue = 1 + dealerCards.get(0).getCardValue();
            otherDealerTotalValue = 11 + dealerCards.get(0).getCardValue();
        } else if (dealerCards.get(0).getCardValue() == 1 && dealerCards.get(1).getCardValue() == 1) {
            dealerTotalValue = 2;
            otherDealerTotalValue = 22;
        } else {
            dealerTotalValue = dealerCards.get(0).getCardValue() + dealerCards.get(1).getCardValue();
            otherDealerTotalValue = dealerCards.get(0).getCardValue() + dealerCards.get(1).getCardValue();
        }

        //Resetting Some Variables before the Loop (Hit Button) and Revealing the Player's Total Score using a JLabel, and hiding the Dealer's Score 
         cardCounter = 4;
         playerCardCounter = 2;
         dealerCardCounter = 2;
         userScore.setText(playerTotalValue + "/" + otherPlayerTotalValue );
         dealerScore.setText("?");
         
         //Ending the Game if the Player or Dealer's Total is Already 21 and Revealing the Dealer's Cards and Total
         //Also, setting the user's total score based on their outcome

        if (otherPlayerTotalValue == 21) {
             outcomeLabel.setText("You have won");
             dealerScore.setText(dealerTotalValue + "/" + otherDealerTotalValue);
             gameOver = true;
             dealerImages[1].setIcon(new javax.swing.ImageIcon(getClass().getResource("/" + dealerCards.get(1).getCardImage())));
             MainGUI.playerDatabase[MainGUI.userPlaying].setWins(MainGUI.playerDatabase[MainGUI.userPlaying].getWins() + 1);
             MainGUI.playerDatabase[MainGUI.userPlaying].setWinsPlusLosses(MainGUI.playerDatabase[MainGUI.userPlaying].getWinsPlusLosses() + 1);
        }
        else if(otherDealerTotalValue == 21){
            gameOver = true;
            outcomeLabel.setText("You have lost");
            dealerScore.setText(dealerTotalValue + "/" + otherDealerTotalValue);
            dealerImages[1].setIcon(new javax.swing.ImageIcon(getClass().getResource("/" + dealerCards.get(1).getCardImage())));
            MainGUI.playerDatabase[MainGUI.userPlaying].setWinsPlusLosses(MainGUI.playerDatabase[MainGUI.userPlaying].getWinsPlusLosses() + 1);
       
        }
        else if(otherPlayerTotalValue == 21 && otherDealerTotalValue == 21){
            outcomeLabel.setText("You have tied");
            dealerImages[1].setIcon(new javax.swing.ImageIcon(getClass().getResource("/" + dealerCards.get(1).getCardImage())));
            gameOver = true;
            dealerScore.setText(dealerTotalValue + "/" + otherDealerTotalValue);
         
        }
        SaveData.Save();
         
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        playerCard14 = new javax.swing.JLabel();
        hitButton = new javax.swing.JButton();
        standButton = new javax.swing.JButton();
        backButton = new javax.swing.JButton();
        userScore = new javax.swing.JLabel();
        dealerScore = new javax.swing.JLabel();
        playerCard4 = new javax.swing.JLabel();
        outcomeLabel = new javax.swing.JLabel();
        playerCard2 = new javax.swing.JLabel();
        playerCard1 = new javax.swing.JLabel();
        playerCard6 = new javax.swing.JLabel();
        playerCard5 = new javax.swing.JLabel();
        playerCard7 = new javax.swing.JLabel();
        playerCard8 = new javax.swing.JLabel();
        playerCard9 = new javax.swing.JLabel();
        playerCard3 = new javax.swing.JLabel();
        playerCard11 = new javax.swing.JLabel();
        playerCard10 = new javax.swing.JLabel();
        dealerCard2 = new javax.swing.JLabel();
        dealerCard1 = new javax.swing.JLabel();
        dealerCard4 = new javax.swing.JLabel();
        dealerCard6 = new javax.swing.JLabel();
        dealerCard5 = new javax.swing.JLabel();
        dealerCard7 = new javax.swing.JLabel();
        dealerCard8 = new javax.swing.JLabel();
        dealerCard9 = new javax.swing.JLabel();
        dealerCard3 = new javax.swing.JLabel();
        dealerCard11 = new javax.swing.JLabel();
        dealerCard10 = new javax.swing.JLabel();
        playAgainButton = new javax.swing.JButton();

        playerCard14.setText("playerCard2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        hitButton.setText("Hit");
        hitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hitButtonActionPerformed(evt);
            }
        });

        standButton.setText("Stand");
        standButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                standButtonActionPerformed(evt);
            }
        });

        backButton.setText("<- Back");
        backButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backButtonActionPerformed(evt);
            }
        });

        outcomeLabel.setFont(new java.awt.Font("Myanmar Sangam MN", 3, 18)); // NOI18N

        playAgainButton.setText("Play Again");
        playAgainButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                playAgainButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(playerCard1, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(playerCard2, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(playerCard3, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(playerCard4, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(playerCard5, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(6, 6, 6)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(userScore))
                                    .addComponent(playerCard6, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(10, 10, 10)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(standButton))
                                    .addComponent(playerCard7, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(hitButton))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(playerCard8, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 25, Short.MAX_VALUE)
                        .addComponent(playerCard9, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(playerCard10, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(playerCard11, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(26, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(dealerCard1, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(dealerCard2, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(dealerCard3, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dealerCard4, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dealerCard5, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(433, 433, 433)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(dealerScore)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(playAgainButton))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addComponent(outcomeLabel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(dealerCard6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 79, Short.MAX_VALUE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(dealerCard7, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(dealerCard8, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(dealerCard9, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(dealerCard10, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(dealerCard11, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGap(0, 0, Short.MAX_VALUE))))
            .addGroup(layout.createSequentialGroup()
                .addComponent(backButton)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(backButton)
                    .addComponent(dealerScore)
                    .addComponent(playAgainButton))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 24, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(dealerCard4, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dealerCard1, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dealerCard2, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dealerCard6, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dealerCard7, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dealerCard8, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dealerCard9, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dealerCard3, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dealerCard11, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dealerCard10, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dealerCard5, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addComponent(outcomeLabel)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(playerCard4, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(playerCard1, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(playerCard2, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(playerCard6, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(playerCard7, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(playerCard8, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(playerCard9, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(playerCard3, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(playerCard11, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(playerCard10, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(playerCard5, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(userScore)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(hitButton)
                        .addComponent(standButton)))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void hitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hitButtonActionPerformed
        // TODO add your handling code here:
       
        //Will only run if game is not over
        if (gameOver == false){
            
            //Adding a Card to the Player Deck and setting the next JLabel to the Image of that Card
            playerCards.add(cardDatabase.get(cardCounter));
            playerImages[playerImageCounter].setIcon(new javax.swing.ImageIcon(getClass().getResource("/" + playerCards.get(playerCardCounter).getCardImage())));
            playerImageCounter++;
            
            //Calculating Player Total and Special Cases if Aces are Drawn
            if(playerCards.get(playerCardCounter).getCardValue() == 1){
                playerTotalValue = playerTotalValue + 1;
                otherPlayerTotalValue = otherPlayerTotalValue + 11;
            }//ending inner if statement
            else{
                playerTotalValue = playerTotalValue + playerCards.get(playerCardCounter).getCardValue();
                otherPlayerTotalValue = otherPlayerTotalValue + playerCards.get(playerCardCounter).getCardValue();
            }//ending inner else statement
            
            //Increasing some Counters and Revealing the Player's New Totals using a JLabel
            cardCounter ++;
            playerCardCounter ++;
            userScore.setText(playerTotalValue + "/" + otherPlayerTotalValue );
        }//ending outer if statement
       
        //Ending the Game Based on If the Player's Total Score Exceeds 21 or if they achieved 21
        //Also revealing Dealer's Scores and Cards, and Setting the User's Total Score Based on their Outcome
        if (playerTotalValue > 21){
            gameOver = true;
            outcomeLabel.setText("You have lost");
            dealerScore.setText(dealerTotalValue + "/" + otherDealerTotalValue);
            dealerImages[1].setIcon(new javax.swing.ImageIcon(getClass().getResource("/" + dealerCards.get(1).getCardImage())));
            MainGUI.playerDatabase[MainGUI.userPlaying].setWinsPlusLosses(MainGUI.playerDatabase[MainGUI.userPlaying].getWinsPlusLosses() + 1);
        }
        
        if(playerTotalValue == 21 || otherPlayerTotalValue == 21){  
            gameOver = true;
            dealerScore.setText(dealerTotalValue + "/" + otherDealerTotalValue);
           
            //Inner if statement for if the dealer and player both tied with totals equal to 21
            if(dealerTotalValue == 21 || otherDealerTotalValue == 21){
            outcomeLabel.setText("You have tied");
            dealerImages[1].setIcon(new javax.swing.ImageIcon(getClass().getResource("/" + dealerCards.get(1).getCardImage())));
            }//ending inner if statement
            
            //Inner else statement for if the player had a total of 21 and the dealer did not
            else{
                outcomeLabel.setText("You have won");
                gameOver = true;
                dealerImages[1].setIcon(new javax.swing.ImageIcon(getClass().getResource("/" + dealerCards.get(1).getCardImage())));
                MainGUI.playerDatabase[MainGUI.userPlaying].setWins(MainGUI.playerDatabase[MainGUI.userPlaying].getWins() + 1);
                MainGUI.playerDatabase[MainGUI.userPlaying].setWinsPlusLosses(MainGUI.playerDatabase[MainGUI.userPlaying].getWinsPlusLosses() + 1);
            }//ending inner else statement
        }//ending outer if statement
        SaveData.Save();
    }//GEN-LAST:event_hitButtonActionPerformed

    private void standButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_standButtonActionPerformed

        //Dealer Will Keep On Receiving New Cards Until The Game Is Over
        while(gameOver == false){
            
            //Dealer's Cards Will Be Revealed
            dealerImages[1].setIcon(new javax.swing.ImageIcon(getClass().getResource("/" + dealerCards.get(1).getCardImage())));
            
            //Ending the Game Based on if they achieved 21 or their Total is Greater than the Player's But Less than 21
            //Also revealing Dealer's Scores and Cards, and Setting the User's Total Score Based on their Outcome
            if(dealerTotalValue > playerTotalValue && dealerTotalValue < 21){
                outcomeLabel.setText("You have lost");
                gameOver = true;
                dealerScore.setText(dealerTotalValue + "/" + otherDealerTotalValue);
                MainGUI.playerDatabase[MainGUI.userPlaying].setWinsPlusLosses(MainGUI.playerDatabase[MainGUI.userPlaying].getWinsPlusLosses() + 1);
            }
            else if(dealerTotalValue == 21 || otherDealerTotalValue == 21){
                outcomeLabel.setText("You have lost");
                gameOver = true;
                dealerScore.setText(dealerTotalValue + "/" + otherDealerTotalValue);
                MainGUI.playerDatabase[MainGUI.userPlaying].setWinsPlusLosses(MainGUI.playerDatabase[MainGUI.userPlaying].getWinsPlusLosses() + 1);
            }
            //Continuing the Game with this else-if statement if the Dealer's Total
            //Is Less than the Player's and Still Below than 21
            else if(dealerTotalValue < playerTotalValue && dealerTotalValue <21){
                dealerCards.add(cardDatabase.get(cardCounter));
                dealerImages[dealerImageCounter].setIcon(new javax.swing.ImageIcon(getClass().getResource("/" + dealerCards.get(dealerCardCounter).getCardImage())));
                dealerImageCounter++;
                
                if(dealerCards.get(dealerCardCounter).getCardValue() == 1){
                    dealerTotalValue = dealerTotalValue + 1;
                    otherDealerTotalValue = otherDealerTotalValue + 11;
                    }//ending inner if statement
                else{
                    dealerTotalValue = dealerTotalValue + dealerCards.get(dealerCardCounter).getCardValue();
                    otherDealerTotalValue = otherDealerTotalValue + dealerCards.get(dealerCardCounter).getCardValue();
                    }//ending inner else statement
        
                cardCounter ++;
                dealerCardCounter++;
            }//ending outer else if statement
            
            //Ending the Game if the Dealer's Total Exceeds 21 or the Dealer and Player's Totals Are Equal
            //Also revealing Dealer's Scores and Cards, and Setting the User's Total Score Based on their Outcome
            else if(dealerTotalValue > 21){
                outcomeLabel.setText("You have won");
                dealerScore.setText(dealerTotalValue + "/" + otherDealerTotalValue);
                gameOver = true;
                MainGUI.playerDatabase[MainGUI.userPlaying].setWins(MainGUI.playerDatabase[MainGUI.userPlaying].getWins() + 1);
                MainGUI.playerDatabase[MainGUI.userPlaying].setWinsPlusLosses(MainGUI.playerDatabase[MainGUI.userPlaying].getWinsPlusLosses() + 1);
            }
            else if (dealerTotalValue == playerTotalValue){
                outcomeLabel.setText("You have tied");
                dealerScore.setText(dealerTotalValue + "/" + otherDealerTotalValue);
                gameOver = true;
            }
           
        }//ending while loop
        SaveData.Save();
    }//GEN-LAST:event_standButtonActionPerformed

    private void playAgainButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_playAgainButtonActionPerformed
        // TODO add your handling code here:
        
        //Resetting the Variables, Arrays, JLabels and ArrayLists to their Initial Values
        
        ArrayList <CardObject> temporaryDeck = new ArrayList<CardObject> ();
        ArrayList <CardObject> temporaryDeck2 = new ArrayList<CardObject> ();
        ArrayList <CardObject> temporaryDeck3 = new ArrayList<CardObject> ();
        
       cardDatabase = temporaryDeck;
       playerCards = temporaryDeck2;
       dealerCards = temporaryDeck3;
        
       cardCounter = 0;
       playerCardCounter = 0;
       dealerCardCounter = 0;
    
             
       playerTotalValue = 0;
       otherPlayerTotalValue = 0;
       dealerTotalValue = 0;
       otherDealerTotalValue = 0;
    
       gameOver = false;
       
       playerImageCounter = 0;
       dealerImageCounter = 0;

       JLabel [] tempDealerImages = new JLabel[] {dealerCard1, dealerCard2, dealerCard3, dealerCard4, dealerCard5, dealerCard6, dealerCard7, dealerCard8, dealerCard9, dealerCard10, dealerCard11};
       JLabel [] tempPlayerImages = new JLabel[] {playerCard1, playerCard2, playerCard3, playerCard4, playerCard5, playerCard6, playerCard7, playerCard8, playerCard9, playerCard10, playerCard11};
         
       playerImages = tempPlayerImages;
       dealerImages = tempDealerImages;
       
       for(int i=0; i < 11; i++){
           playerImages[i].setIcon(null);
           dealerImages[i].setIcon(null);
       }
       
       userScore.setText(null);
       dealerScore.setText(null);
       outcomeLabel.setText(null);
       
       //Randomizing and Creating the Deck of 52 Cards and Making their Jacks, Queens and Kings's Values Equal to 10
       //Surrounded with a Try-Catch Statement to Prevent Errors
        try {
            CardObject.createCardDeck(cardDatabase);
        } catch (IOException ex) {
            Logger.getLogger(BlackJackGUI.class.getName()).log(Level.SEVERE, null, ex);
        }
         cardDatabase = CardObject.shuffleCardDeck(cardDatabase);
         CardObject.makeJacksKingsQueensValueTo10(cardDatabase);
         

         //Adding two cards to the Player Deck
  
         playerCards.add(cardDatabase.get(cardCounter));
         playerCards.add(cardDatabase.get(cardCounter +1));
         
         //Setting the Jlabels to the Player Card Images Above
         
         playerImages[playerImageCounter].setIcon(new javax.swing.ImageIcon(getClass().getResource("/" + playerCards.get(0).getCardImage())));
         playerImageCounter++;
         playerImages[playerImageCounter].setIcon(new javax.swing.ImageIcon(getClass().getResource("/" + playerCards.get(1).getCardImage())));
         playerImageCounter++;
         
         //Calculating Player's Total and their Other Total (special cases, if the Player's Cards Are Aces)
         
         if(playerCards.get(0).getCardValue() == 1 && playerCards.get(1).getCardValue() != 1){
             playerTotalValue = 1 + playerCards.get(1).getCardValue();
             otherPlayerTotalValue = 11 + playerCards.get(1).getCardValue();
         }
         else if(playerCards.get(0).getCardValue() != 1 && playerCards.get(1).getCardValue() == 1){
             playerTotalValue = 1 + playerCards.get(0).getCardValue();
             otherPlayerTotalValue = 11 + playerCards.get(0).getCardValue();
         }
         else if(playerCards.get(0).getCardValue() == 1 && playerCards.get(1).getCardValue() == 1){
             playerTotalValue = 2;
             otherPlayerTotalValue = 22;
         }
         else{
             playerTotalValue = playerCards.get(0).getCardValue() + playerCards.get(1).getCardValue();
             otherPlayerTotalValue = playerCards.get(0).getCardValue() + playerCards.get(1).getCardValue();
         }
         
         //Adding two cards to the Dealer Deck
         
         dealerCards.add(cardDatabase.get(cardCounter +2));
         dealerCards.add(cardDatabase.get(cardCounter +3));
         
         //Setting the Jlabels to the Dealer Card Images Above, and Leaving the Second Card Face-Down
         
         dealerImages[dealerImageCounter].setIcon(new javax.swing.ImageIcon(getClass().getResource("/" + dealerCards.get(0).getCardImage())));
         dealerImageCounter++;
         dealerImages[dealerImageCounter].setIcon(new javax.swing.ImageIcon(getClass().getResource("/backOfCard.png")));
         dealerImageCounter++;
         
         //Calculating Dealer's Total and their Other Total (special cases, if the Dealer's Cards Are Aces)
         
         if (dealerCards.get(0).getCardValue() == 1 && dealerCards.get(1).getCardValue() != 1) {
            dealerTotalValue = 1 + dealerCards.get(1).getCardValue();
            otherDealerTotalValue = 11 + dealerCards.get(1).getCardValue();
        } else if (dealerCards.get(0).getCardValue() != 1 && dealerCards.get(1).getCardValue() == 1) {
            dealerTotalValue = 1 + dealerCards.get(0).getCardValue();
            otherDealerTotalValue = 11 + dealerCards.get(0).getCardValue();
        } else if (dealerCards.get(0).getCardValue() == 1 && dealerCards.get(1).getCardValue() == 1) {
            dealerTotalValue = 2;
            otherDealerTotalValue = 22;
        } else {
            dealerTotalValue = dealerCards.get(0).getCardValue() + dealerCards.get(1).getCardValue();
            otherDealerTotalValue = dealerCards.get(0).getCardValue() + dealerCards.get(1).getCardValue();
        }

        //Resetting Some Variables before the Loop (Hit Button) and Revealing the Player's Total Score using a JLabel, and hiding the Dealer's Score 
         cardCounter = 4;
         playerCardCounter = 2;
         dealerCardCounter = 2;
         userScore.setText(playerTotalValue + "/" + otherPlayerTotalValue );
         dealerScore.setText("?");
         
         //Ending the Game if the Player or Dealer's Total is Already 21 and Revealing the Dealer's Cards and Total
         //Also, setting the user's total score based on their outcome

        if (otherPlayerTotalValue == 21) {
             outcomeLabel.setText("You have won");
             dealerScore.setText(dealerTotalValue + "/" + otherDealerTotalValue);
             gameOver = true;
             dealerImages[1].setIcon(new javax.swing.ImageIcon(getClass().getResource("/" + dealerCards.get(1).getCardImage())));
             MainGUI.playerDatabase[MainGUI.userPlaying].setWins(MainGUI.playerDatabase[MainGUI.userPlaying].getWins() + 1);
             MainGUI.playerDatabase[MainGUI.userPlaying].setWinsPlusLosses(MainGUI.playerDatabase[MainGUI.userPlaying].getWinsPlusLosses() + 1);
        }
        else if(otherDealerTotalValue == 21){
            gameOver = true;
            outcomeLabel.setText("You have lost");
            dealerScore.setText(dealerTotalValue + "/" + otherDealerTotalValue);
            dealerImages[1].setIcon(new javax.swing.ImageIcon(getClass().getResource("/" + dealerCards.get(1).getCardImage())));
            MainGUI.playerDatabase[MainGUI.userPlaying].setWinsPlusLosses(MainGUI.playerDatabase[MainGUI.userPlaying].getWinsPlusLosses() + 1);
       
        }
        else if(otherPlayerTotalValue == 21 && otherDealerTotalValue == 21){
            outcomeLabel.setText("You have tied");
            dealerImages[1].setIcon(new javax.swing.ImageIcon(getClass().getResource("/" + dealerCards.get(1).getCardImage())));
            gameOver = true;
            dealerScore.setText(dealerTotalValue + "/" + otherDealerTotalValue);
         
        }
        SaveData.Save();
        
        
    }//GEN-LAST:event_playAgainButtonActionPerformed

    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButtonActionPerformed
        // TODO add your handling code here:
        //Sending the User Back to the Game Menu Screen
        new GameMenu().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_backButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BlackJackGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BlackJackGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BlackJackGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BlackJackGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new BlackJackGUI().setVisible(true);
                } catch (IOException ex) {
                    Logger.getLogger(BlackJackGUI.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });

        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backButton;
    private javax.swing.JLabel dealerCard1;
    private javax.swing.JLabel dealerCard10;
    private javax.swing.JLabel dealerCard11;
    private javax.swing.JLabel dealerCard2;
    private javax.swing.JLabel dealerCard3;
    private javax.swing.JLabel dealerCard4;
    private javax.swing.JLabel dealerCard5;
    private javax.swing.JLabel dealerCard6;
    private javax.swing.JLabel dealerCard7;
    private javax.swing.JLabel dealerCard8;
    private javax.swing.JLabel dealerCard9;
    private javax.swing.JLabel dealerScore;
    private javax.swing.JButton hitButton;
    private javax.swing.JLabel outcomeLabel;
    private javax.swing.JButton playAgainButton;
    private javax.swing.JLabel playerCard1;
    private javax.swing.JLabel playerCard10;
    private javax.swing.JLabel playerCard11;
    private javax.swing.JLabel playerCard14;
    private javax.swing.JLabel playerCard2;
    private javax.swing.JLabel playerCard3;
    private javax.swing.JLabel playerCard4;
    private javax.swing.JLabel playerCard5;
    private javax.swing.JLabel playerCard6;
    private javax.swing.JLabel playerCard7;
    private javax.swing.JLabel playerCard8;
    private javax.swing.JLabel playerCard9;
    private javax.swing.JButton standButton;
    private javax.swing.JLabel userScore;
    // End of variables declaration//GEN-END:variables
}
