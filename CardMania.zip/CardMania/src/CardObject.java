
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import javax.imageio.ImageIO;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * CardObject Class
 * This is a class designed to create an object for a playing card. Includes constructor, getter and setter methods.
 * Also, includes methods to create a deck of 52 cards, and another method to shuffle that deck,
 * Also, includes a method to make all the Jacks, Kings and Queens of the Deck Value Equal to 10
 *
 * Version 16.02.2020
 * @author 002872 - 0040
 */
public class CardObject {
    
    private int cardID;
    private String cardSuit;
    private int cardValue;
    private boolean faceUp;
    private String cardImage;

    //constructor methods
    
    CardObject() throws IOException {
        cardID = -1;
        cardSuit = "-";
        cardValue = -1;
        faceUp = false;
        cardImage = "backOfCard.png";
        
                
    }

    public CardObject(int cardID, String cardSuit, int cardValue, boolean faceUp, String cardImage) {
        this.cardID = cardID;
        this.cardSuit = cardSuit;
        this.cardValue = cardValue;
        this.faceUp = faceUp;
        this.cardImage = cardImage;
    }
    
    //getter methods
    
    String getCardSuit(){
        return this.cardSuit;
    }
    
    int getCardValue(){
        return this.cardValue;
    }
    
    boolean getFaceUp(){
        return this.faceUp;
    }
    
    String getCardImage(){
        return this.cardImage;
    }
    
    int getCardID(){
        return this.cardID;
    }
    
    //setter methods
    
    void setCardSuit(String cardSuit){
        this.cardSuit = cardSuit;
    }
    
    void setCardValue(int cardValue){
        this.cardValue = cardValue;
    }
    
    void setFaceUp(boolean faceUp){
        this.faceUp = faceUp;
    }
    
    void setCardImage(String cardImage){
        this.cardImage = cardImage;
    }
    
    void setCardID(int cardID){
        this.cardID = cardID;
    }
    
    // Method for Creating the Card Database (all 52 playing cards in a deck)
    
    public static void createCardDeck (ArrayList <CardObject> cardDatabase) throws IOException{
        
        
        for (int i=0; i < 52; i++){
            cardDatabase.add(new CardObject());
        }
        //constructing an ArrayList out of 52 CardObjects
        
        int cardCounter = 0;
        
        for (int i=0; i < 13; i++){
            //outer loop for setting card numbers
            
            for (int j=0; j < 4; j++){
                //inner loop for setting card suits
                
                String [] suitStrings = new String [] {"C", "D", "H", "S"};
                
                //setting values into each CardObject
               
                cardDatabase.get(cardCounter).setCardID(cardCounter + 1);
                cardDatabase.get(cardCounter).setCardValue(i+1);
                cardDatabase.get(cardCounter).setCardSuit(suitStrings[j]);
                cardDatabase.get(cardCounter).setCardImage(Integer.toString(i+1) + suitStrings[j] + ".png");
                
                cardCounter++;
                
            }
        }
        
    }
    
   
    //Method for Shuffling the Card Deck.
    //The Method Creates A New ArrayList, Takes Random Cards from the CardDatabase
    //Then, those cards are removed from the CardDatabase
    //The temporarydeck would then be returned as the new CardDatabase
    public static ArrayList <CardObject> shuffleCardDeck (ArrayList <CardObject> cardDatabase){
        //Creating a temporary deck
        ArrayList <CardObject> temporaryDeck = new ArrayList<CardObject> ();
        
        Random random = new Random ();
        int randomCardIndex = 0;
        int originalSize = cardDatabase.size();
        
        for (int i=0; i < originalSize; i++){
            
            //Finding a random CardObject and adding it to the temporaryDeck
            //and removing it from the Card Database so it would not be added
            //to the temporaryDeck again
            randomCardIndex = random.nextInt((cardDatabase.size() -1 - 0) + 1) + 0;
            temporaryDeck.add(cardDatabase.get(randomCardIndex));
            cardDatabase.remove(randomCardIndex);
        }
        
        return temporaryDeck;
   
            
      
    }
    
    //Method for Making all the Jacks, Kings and Queens in the Deck's Values Equal to 10
    public static void makeJacksKingsQueensValueTo10 (ArrayList <CardObject> cardDatabase2){

    
        for (int i=0; i < 52; i++){
            if (cardDatabase2.get(i).getCardValue() == 11 || cardDatabase2.get(i).getCardValue() == 12 || cardDatabase2.get(i).getCardValue() == 13){
                cardDatabase2.get(i).setCardValue(10);
            }
        }

          
    }
    
    
    public static void main(String [] args) throws IOException{


        
    }
    
    
    
    
  
}