
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * War Game Code
 * 
 * This is the code that runs the War game, and allows it to be repeatedly played, whilst adding points to the user's scores
 *
 * INSTRUCTIONS:
 * -A deck of 52 cards is shuffled and split evenly between the player and the dealer
 * -Once a new card is added, both the player and dealer draw a card from the deck, and whoever's card value is higher would win a point
 * -If their values are equal, war will be initiated and two cards are each drawn by the player and dealer, with the first card drawn being face down. The second card is face-up, and whoever's second card value is higher than the other, would win 3 points. If their second card values are equal again, war will happen repeatedly until one person's second card value is higher than the other. The points that the war winner will receive will repeatedly add up.
 * -Once there are no cards left in either the player or dealer's deck, whoever has the most points will win the round, or if their points are equal, the game will be tied
 * 
 * Version 16.02.20
 * @author 002872 - 0040
 */
public class WarGUI extends javax.swing.JFrame {

    /**
     * Creates new form WarGUI
     */
    
    //Creates Three ArrayLists:
    //PlayerCards contains the Player's Cards
    //DealerCards contains the Dealer's Cards
    //CardDatabase contains a deck of 52 cards
    ArrayList<CardObject> playerCards = new ArrayList<CardObject> ();
    ArrayList<CardObject> dealerCards = new ArrayList<CardObject> ();
    ArrayList<CardObject> cardDatabase = new ArrayList<CardObject> ();
    
    //Initialising Variables         
    int cardCounter = 0;
    int playerScore = 0;
    int dealerScore = 0;
    
    
    public WarGUI() throws IOException, InterruptedException {
        initComponents();
        
         //Shuffling and Creating a Deck of 52 Cards
         CardObject.createCardDeck(cardDatabase);
         cardDatabase = CardObject.shuffleCardDeck(cardDatabase);
         
         //Splitting a Deck of 52 Cards into Two for the Player and Dealer Each
         for (int i=0; i < 26; i++){
             playerCards.add(cardDatabase.get(i));
         }
         for (int i=26; i < 52; i++){
             dealerCards.add(cardDatabase.get(i));
         }
         
         //Setting JLabels to the Card Images of the First Player and Dealer Cards
         playerCard.setIcon(new javax.swing.ImageIcon(getClass().getResource("/" + playerCards.get(cardCounter).getCardImage())));
         dealerCard.setIcon(new javax.swing.ImageIcon(getClass().getResource("/" + dealerCards.get(cardCounter).getCardImage())));
         
         //Increasing Counters and Increasing the Scores of a Player or Dealer
         //This depends on whose card value is higher
         if (playerCards.get(cardCounter).getCardValue() < dealerCards.get(cardCounter).getCardValue()){
             dealerScore++;
             cardCounter++;
         }
         else if (playerCards.get(cardCounter).getCardValue() > dealerCards.get(cardCounter).getCardValue()){
             playerScore++;
             cardCounter++;
         }
         //If card values are equal, then war is initiated
         else if (playerCards.get(cardCounter).getCardValue() == dealerCards.get(cardCounter).getCardValue()){
             //Initialising Variables
             boolean cardsNotEqual = true;
             int additionValue = 3;
             //Creating a while loop.
             //Loop continues until card values are unequal
             while (cardsNotEqual == true){
                 outcomeLabel.setText("WAR");
                 //Increasing CardCounter
                 cardCounter++;
                 //JLabels are Set to the Next 2 Player/Dealer Cards Card Images
                 //First Cards are Face-Down, Second Cards are Face-Up
                 playerWarCard1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/backOfCard.png")));
                 dealerWarCard1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/backOfCard.png")));
                 cardCounter++;
                 playerWarCard2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/" + playerCards.get(cardCounter).getCardImage())));
                 dealerWarCard2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/" + dealerCards.get(cardCounter).getCardImage())));
                 
                 //Second card values are evaluated if they are higher or lower or if equal, outer while loop does not stop
                 if (playerCards.get(cardCounter).getCardValue() < dealerCards.get(cardCounter).getCardValue()){
                     dealerScore = dealerScore + additionValue;
                     cardsNotEqual = false;
                     cardCounter ++;
                 } //end inner if statement
                 else if (playerCards.get(cardCounter).getCardValue() > dealerCards.get(cardCounter).getCardValue()){
                     playerScore = playerScore + additionValue;
                     cardsNotEqual = false;
                     cardCounter++;
                 } //end inner else if statement
                 else if(playerCards.get(cardCounter).getCardValue() == dealerCards.get(cardCounter).getCardValue()){
                     additionValue = additionValue + 2;
                 } //end inner else if statement
             } //end inner while statement      
         } //end outer else if statement
         //Player and Dealer Scores Are Displayed
         playerScoreLabel.setText(Integer.toString(playerScore));
         dealerScoreLabel.setText(Integer.toOctalString(dealerScore));

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        dealerCard = new javax.swing.JLabel();
        playerCard = new javax.swing.JLabel();
        dealerWarCard2 = new javax.swing.JLabel();
        dealerWarCard1 = new javax.swing.JLabel();
        playerWarCard2 = new javax.swing.JLabel();
        playerWarCard1 = new javax.swing.JLabel();
        backButton = new javax.swing.JButton();
        playAgainButton = new javax.swing.JButton();
        playerScoreLabel = new javax.swing.JLabel();
        dealerScoreLabel = new javax.swing.JLabel();
        newCardButton = new javax.swing.JButton();
        outcomeLabel = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        backButton.setText("<- Back");
        backButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backButtonActionPerformed(evt);
            }
        });

        playAgainButton.setText("Play Again");
        playAgainButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                playAgainButtonActionPerformed(evt);
            }
        });

        newCardButton.setText("New Card");
        newCardButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newCardButtonActionPerformed(evt);
            }
        });

        outcomeLabel.setFont(new java.awt.Font("Myanmar Sangam MN", 3, 18)); // NOI18N
        outcomeLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        jLabel1.setFont(new java.awt.Font("Lucida Grande", 1, 13)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1.setText("Score:");

        jLabel2.setFont(new java.awt.Font("Lucida Grande", 1, 13)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("Score:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(93, 93, 93)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(playerCard, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(137, 137, 137)
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(playerScoreLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(newCardButton)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(dealerCard, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(137, 137, 137)
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dealerScoreLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 131, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(dealerWarCard2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(playerWarCard1, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(playerWarCard2, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(59, 59, 59))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(591, 591, 591)
                        .addComponent(playAgainButton)
                        .addContainerGap())))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(backButton))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(262, 262, 262)
                        .addComponent(outcomeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addContainerGap(584, Short.MAX_VALUE)
                    .addComponent(dealerWarCard1, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(159, 159, 159)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(175, 175, 175)
                        .addComponent(dealerWarCard2, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(backButton)
                            .addComponent(playAgainButton))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 127, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(dealerCard, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(130, 130, 130))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(dealerScoreLabel)
                                    .addComponent(jLabel1))
                                .addGap(116, 116, 116)
                                .addComponent(outcomeLabel)
                                .addGap(68, 68, 68)))))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(playerWarCard2, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(playerCard, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(playerWarCard1, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(46, 46, 46)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(playerScoreLabel)
                            .addComponent(jLabel2))))
                .addGap(24, 24, 24)
                .addComponent(newCardButton)
                .addGap(21, 21, 21))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(177, 177, 177)
                    .addComponent(dealerWarCard1, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(328, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButtonActionPerformed
        // TODO add your handling code here:
        //Sends User to Game Menu GUI
        new GameMenu().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_backButtonActionPerformed

    private void newCardButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newCardButtonActionPerformed
        // TODO add your handling code here:

        //Code Stops Running When Card Counter = 26, i.e when game is over
        if (cardCounter != 26){
            //Labels are reset
            outcomeLabel.setText(null);
            playerWarCard1.setIcon(null);
            playerWarCard2.setIcon(null);
            dealerWarCard1.setIcon(null);
            dealerWarCard2.setIcon(null);
            
            //JLabels are set to the next Card Images
            playerCard.setIcon(new javax.swing.ImageIcon(getClass().getResource("/" + playerCards.get(cardCounter).getCardImage())));
            dealerCard.setIcon(new javax.swing.ImageIcon(getClass().getResource("/" + dealerCards.get(cardCounter).getCardImage())));
            
            //Increasing Counters and Increasing the Scores of a Player or Dealer
            //This depends on whose card value is higher
            if (playerCards.get(cardCounter).getCardValue() < dealerCards.get(cardCounter).getCardValue()){
                dealerScore++;
                cardCounter++;
            }
            else if (playerCards.get(cardCounter).getCardValue() > dealerCards.get(cardCounter).getCardValue()){
                playerScore++;
                cardCounter++;
            }
            else if (playerCards.get(cardCounter).getCardValue() == dealerCards.get(cardCounter).getCardValue()){
                //Initialsing Variables
                boolean cardsNotEqual = true;
                int additionValue = 3;
                //Creating a while loop.
                //Loop continues until card values are unequal 
                //Or continues until not enough cards to be dealt
                while (cardsNotEqual == true && cardCounter != 24 && cardCounter != 25 && cardCounter != 26){
                    outcomeLabel.setText("WAR");
                    cardCounter++;
                    
                    //JLabels are Set to the Next 2 Player/Dealer Cards Card Images
                    //First Cards are Face-Down, Second Cards are Face-Up
                    playerWarCard1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/backOfCard.png")));
                    dealerWarCard1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/backOfCard.png")));
                    cardCounter++;
                    playerWarCard2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/" + playerCards.get(cardCounter).getCardImage())));
                    dealerWarCard2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/" + dealerCards.get(cardCounter).getCardImage())));
                    
                    //Second card values are evaluated if they are higher or lower or if equal, outer while loop does not stop
                    if (playerCards.get(cardCounter).getCardValue() < dealerCards.get(cardCounter).getCardValue()){
                        dealerScore = dealerScore + additionValue;
                        cardsNotEqual = false;
                        cardCounter ++;
                    }//end inner if statement
                    else if (playerCards.get(cardCounter).getCardValue() > dealerCards.get(cardCounter).getCardValue()){
                        playerScore = playerScore + additionValue;
                        cardsNotEqual = false;
                        cardCounter++;
                    }//end inner else if statement
                    else if(playerCards.get(cardCounter).getCardValue() == dealerCards.get(cardCounter).getCardValue()){
                        additionValue = additionValue + 2;
                    }//end inner else if statement
                }//end outer while loop
                if (cardCounter == 24 || cardCounter == 25) {
                    cardCounter = 26;
                }
         }//end outer else if statement
         //Player and Dealer Scores Are Displayed
         playerScoreLabel.setText(Integer.toString(playerScore));
         dealerScoreLabel.setText(Integer.toString(dealerScore));
            
            
        }//end outer if statement
        
        //Code for When All Cards Are Dealt, game is over
        //Outcomes are displayed, User's Score is set based on outcome
        else if (cardCounter == 26){
            if (playerScore < dealerScore){
                outcomeLabel.setText("You have lost");
                MainGUI.playerDatabase[MainGUI.userPlaying].setWinsPlusLosses(MainGUI.playerDatabase[MainGUI.userPlaying].getWinsPlusLosses() + 1);
            }//end inner if statement
            else if (playerScore > dealerScore){
                outcomeLabel.setText("You have won");
                MainGUI.playerDatabase[MainGUI.userPlaying].setWins(MainGUI.playerDatabase[MainGUI.userPlaying].getWins() + 1);
                MainGUI.playerDatabase[MainGUI.userPlaying].setWinsPlusLosses(MainGUI.playerDatabase[MainGUI.userPlaying].getWinsPlusLosses() + 1);
            }//end inner else if statement
            else if(playerScore == dealerScore){
                outcomeLabel.setText("You have tied");
            }//end inner else if statement
        }//end outer else if statement
        SaveData.Save();
    }//GEN-LAST:event_newCardButtonActionPerformed

    private void playAgainButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_playAgainButtonActionPerformed
        // TODO add your handling code here:
        //JLabels, Variables and ArrayLists Are Reset
        playerScoreLabel.setText(null);
        dealerScoreLabel.setText(null);
        outcomeLabel.setText(null);
        playerCard.setIcon(null);
        playerWarCard1.setIcon(null);
        playerWarCard2.setIcon(null);
        dealerCard.setIcon(null);
        dealerWarCard1.setIcon(null);
        dealerWarCard2.setIcon(null);
        
        cardCounter = 0;
        playerScore = 0;
        dealerScore = 0;
        
        ArrayList <CardObject> temporaryDeck = new ArrayList<CardObject> ();
        ArrayList <CardObject> temporaryDeck2 = new ArrayList<CardObject> ();
        ArrayList <CardObject> temporaryDeck3 = new ArrayList<CardObject> ();
        
        cardDatabase = temporaryDeck;
        playerCards = temporaryDeck2;
        dealerCards = temporaryDeck3;
        
        //Shuffling and Creating A Deck of Cards
        //Surrounded by Try-Catch Statement to Prevent Errors
        try {
            CardObject.createCardDeck(cardDatabase);
        } catch (IOException ex) {
            Logger.getLogger(WarGUI.class.getName()).log(Level.SEVERE, null, ex);
        }
         cardDatabase = CardObject.shuffleCardDeck(cardDatabase);
         
         //Splitting a Deck of 52 Cards into Two for the Player and Dealer Each
         for (int i=0; i < 26; i++){
             playerCards.add(cardDatabase.get(i));
         }
         for (int i=26; i < 52; i++){
             dealerCards.add(cardDatabase.get(i));
         }
         
         //Setting JLabels to the Card Images of the First Player and Dealer Cards
         playerCard.setIcon(new javax.swing.ImageIcon(getClass().getResource("/" + playerCards.get(cardCounter).getCardImage())));
         dealerCard.setIcon(new javax.swing.ImageIcon(getClass().getResource("/" + dealerCards.get(cardCounter).getCardImage())));
         
         //Increasing Counters and Increasing the Scores of a Player or Dealer
         //This depends on whose card value is higher
         if (playerCards.get(cardCounter).getCardValue() < dealerCards.get(cardCounter).getCardValue()){
             dealerScore++;
             cardCounter++;
         }
         else if (playerCards.get(cardCounter).getCardValue() > dealerCards.get(cardCounter).getCardValue()){
             playerScore++;
             cardCounter++;
         }
         //If card values are equal, then war is initiated
         else if (playerCards.get(cardCounter).getCardValue() == dealerCards.get(cardCounter).getCardValue()){
             //Initialising Variables
             boolean cardsNotEqual = true;
             int additionValue = 3;
             //Creating a while loop.
             //Loop continues until card values are unequal
             while (cardsNotEqual == true){
                 outcomeLabel.setText("WAR");
                 //Increasing CardCounter
                 cardCounter++;
                 //JLabels are Set to the Next 2 Player/Dealer Cards Card Images
                 //First Cards are Face-Down, Second Cards are Face-Up
                 playerWarCard1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/backOfCard.png")));
                 dealerWarCard1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/backOfCard.png")));
                 cardCounter++;
                 playerWarCard2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/" + playerCards.get(cardCounter).getCardImage())));
                 dealerWarCard2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/" + dealerCards.get(cardCounter).getCardImage())));
                 
                 //Second card values are evaluated if they are higher or lower or if equal, outer while loop does not stop
                 if (playerCards.get(cardCounter).getCardValue() < dealerCards.get(cardCounter).getCardValue()){
                     dealerScore = dealerScore + additionValue;
                     cardsNotEqual = false;
                     cardCounter ++;
                 } //end inner if statement
                 else if (playerCards.get(cardCounter).getCardValue() > dealerCards.get(cardCounter).getCardValue()){
                     playerScore = playerScore + additionValue;
                     cardsNotEqual = false;
                     cardCounter++;
                 } //end inner else if statement
                 else if(playerCards.get(cardCounter).getCardValue() == dealerCards.get(cardCounter).getCardValue()){
                     additionValue = additionValue + 2;
                 } //end inner else if statement
             } //end inner while statement      
         } //end outer else if statement
         //Player and Dealer Scores Are Displayed
         playerScoreLabel.setText(Integer.toString(playerScore));
         dealerScoreLabel.setText(Integer.toOctalString(dealerScore));

    }//GEN-LAST:event_playAgainButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(WarGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(WarGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(WarGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(WarGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new WarGUI().setVisible(true);
                } catch (IOException ex) {
                    Logger.getLogger(WarGUI.class.getName()).log(Level.SEVERE, null, ex);
                } catch (InterruptedException ex) {
                    Logger.getLogger(WarGUI.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backButton;
    private javax.swing.JLabel dealerCard;
    private javax.swing.JLabel dealerScoreLabel;
    private javax.swing.JLabel dealerWarCard1;
    private javax.swing.JLabel dealerWarCard2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JButton newCardButton;
    private javax.swing.JLabel outcomeLabel;
    private javax.swing.JButton playAgainButton;
    private javax.swing.JLabel playerCard;
    private javax.swing.JLabel playerScoreLabel;
    private javax.swing.JLabel playerWarCard1;
    private javax.swing.JLabel playerWarCard2;
    // End of variables declaration//GEN-END:variables
}
